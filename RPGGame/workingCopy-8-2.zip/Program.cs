﻿using System;
using System.Threading;

namespace RPGGame
{
  class Program
  {
    // Andrew Borondia
    static void Main()
    {
      GameEngine.StartGame();
    }
  }
}